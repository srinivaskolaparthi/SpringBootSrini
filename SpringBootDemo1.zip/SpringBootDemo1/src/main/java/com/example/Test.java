package com.example;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.Mapping;

@Service("Test")
public class Test {


	public String test()
	{
		return "KOLAPARTHI SRINI";
	}
}
