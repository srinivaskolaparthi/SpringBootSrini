package com.javasampleapproach.unittest.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.javasampleapproach.unittest.model.Customer;

@RestController
public class WebController {

	@RequestMapping(value = "/customer", method = RequestMethod.GET)
	public Customer getAddress() {

		Customer customer = new Customer();
		customer.setName("Jack");
		customer.setLocation("US");

		return customer;
	}
}
